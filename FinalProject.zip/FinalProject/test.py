import SmartSafeUtils as ssu
import time
servo = ssu.ServoModule(16)
time.sleep(1)
