cd /
cd home/qpdoyle/Desktop/FinalProject
export FLASK_APP=app.py
sleep 1
sudo flask run --host=0.0.0.0
